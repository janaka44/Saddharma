psql "postgresql://admin:admin@db-postgresql-blr1-93202-do-user-8462003-0.b.db.ondigitalocean.com:25060/legaldb?sslmode=require"

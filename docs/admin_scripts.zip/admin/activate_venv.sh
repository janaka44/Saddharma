cd /home/django/legaloffice/
. venv/bin/activate


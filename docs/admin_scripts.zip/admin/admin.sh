#!/bin/bash
# Bash Menu Script Example

echo "
888                                888  .d88888b.   .d888  .d888                      8888888b.  8888888b.   .d88888b.  
888                                888 d88P   Y88b d88P   d88P                        888   Y88b 888   Y88b d88P   Y88b 
888                                888 888     888 888    888                         888    888 888    888 888     888 
888      .d88b.   .d88b.   8888b.  888 888     888 888888 888888 888  .d8888b .d88b.  888   d88P 888   d88P 888     888 
888     d8P  Y8b d88P 88b      88b 888 888     888 888    888    888 d88P    d8P  Y8b 8888888P   8888888P   888     888 
888     88888888 888  888 .d888888 888 888     888 888    888    888 888     88888888 888        888 T88b   888     888 
888     Y8b.     Y88b 888 888  888 888 Y88b. .d88P 888    888    888 Y88b.   Y8b.     888        888  T88b  Y88b. .d88P 
88888888 Y8888     Y88888  Y888888 888   Y88888P   888    888    888   Y8888P  Y8888  888        888   T88b   Y88888P.  
                      888                                                                                               
                 Y8b d88P                                                                                               
                   Y88P'                                                                                                

Admin Tool ©2021 | LegalOfficePro.com

"

PS3='Please enter your choice nunmber: '
options=("Restart Servers" "Update Live App" "Login to DB" "Create New Customer" "Activate Python Virtual Env"  "Quit")
select opt in "${options[@]}"
do
    case $REPLY in
        "1")
	    . /home/django/admin/restart_servers.sh
            ;;
        "2")
            . /home/django/admin/update_legalOffice.sh
            ;;
        "3")
            echo "Connecting to DB..."
            . /home/django/admin/connect_db.sh
            ;;
        "4")
            echo "Creating new customer..."
	    . /home/django/admin/setup_tenant_customer.sh
            ;;
	"5")
	   echo "Activating Python Virtual Env..."
	   . /home/django/admin/activate_venv.sh
	   break
	   ;;
        "6")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done

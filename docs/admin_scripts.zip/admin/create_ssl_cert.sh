sudo certbot --nginx -d legalofficepro.com -d www.legalofficepro.com -d demo.legalofficepro.com -d sa.legalofficepro.com
sudo systemctl status certbot.timer


